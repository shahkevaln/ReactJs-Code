## ToDo App - React - Redux

How to start?
 1. `$ git clone https://github.com/gaurav51289/react-redux-todo.git`
 1. `$ cd react-redux-todo`
 1. `$ npm install`
 1. Switch to branch `$ git checkout reduxfinal`
 1. `$ npm start`