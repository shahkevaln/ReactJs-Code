import React, {Component} from 'react';
import {connect} from 'react-redux';

import {addTodo, removeAll} from "../actions/index";

import TodoItem from "./TodoItem";

import {removeTodo} from "../actions/index";


var abc={float:'right'};
var xyz={float:'left'};
class MyToDo extends Component {

    render() {
        console.log(this.props);
        return (
            <div className="container-fluid">
                <div className="row justify-content-md-center">
                    <div className="col-md-6">
                        <h2 className="text-center">My Todos</h2>
                    </div>

                </div>
                <hr/>
               {/* <div className="row justify-content-md-center">
                    <div className="col-md-6">
                        <div className="form-group">
                            <input
                                className="form-control"
                                ref={(input) => this.input = input}
                                type="text"
                                placeholder="Enter a Todo"
                            />
                        </div>
                        <button
                            className="btn btn-primary btn-sm"
                            onClick={() => {
                                this.props.addTodo(this.input.value)
                            }}
                        >Add</button>
                    </div>
                </div>*/}

                <hr/>
                <div className="row justify-content-md-center">
                    <div className="card col-sm-4">
                        <div className="card-body">
                            <h4>Menu</h4>
                            {
                                this.props.todoArr.map((todo,index) => {
                                    if (todo.status == 'active') {
                                        return (
                                            <TodoItem
                                                key={index}
                                                item={todo}
                                            />
                                        );
                                    }
                                })
                            }
                        </div>
                    </div>



                    <div className="card col-sm-4">
                        <div className="card-body">
                            <h4>Order</h4>
                            {
                                this.props.todoArr.map((todo,index) => {
                                    if (todo.status == 'done') {
                                        return (
                                            <TodoItem
                                                key={index}
                                                item={todo}
                                            />
                                        );
                                    }
                                })
                            }

                        </div>




                        <div className="row justify-content-md-center">
                            <div className="col-md-12">


                                {/*<button
                                    className="btn btn-primary btn-sm" style={abc}
                                    onClick={() => {
                                        this.props.removeAll(this.props.todoArr)
                                    }}
                                ><span aria-hidden={true}>Remove All</span></button>*/}
                                <span aria-hidden={true} style={xyz}>Total :</span>
                                <span aria-hidden={true} style={abc}>{sumProperty(this.props.todoArr,'price','done')}</span>
                            </div>
                        </div>

                        </div>
                </div>
            </div>
        );
    }
}

function sumProperty(arr, type,status) {
    return arr.reduce((total, obj) => {
        if(obj['status']!=status){
            return total;
        }
        if (typeof obj[type] === 'string') {
            return total + Number(obj[type]);
        }
        return total + obj[type];
    }, 0);
}








function mapStateToProps(todos) {
    const todoArr = Object.keys(todos).map((item) => (
        {
            'todo' : item,
            'price' : todos[item].price,
            'status' : todos[item].status
        }
    ));
    return {todoArr};
}

function mapDispatchToProps(dispatch) {
    return {
        addTodo : (data) => dispatch(addTodo(data)),
        removeTodo : (data) => dispatch(removeTodo(data))
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(MyToDo);    // Learn 'Currying' in functional programming
