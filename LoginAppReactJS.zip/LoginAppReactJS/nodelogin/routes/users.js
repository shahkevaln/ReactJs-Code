var express = require('express');
var router = express.Router();
var mysql = require('./mysql');

/*var users = [
    {
        username: "Mike",
        password: "mike123"
    },
    {
        username: "Tom",
        password: "tom123"
    },
    {
        username: "John",
        password: "john123"
    },
    {
        username: "Mac",
        password: "mac123"
    }
];*/

/* GET users listing. */
router.get('/', function (req, res, next) {
    res.send('respond with a resource');
});

router.post('/doLogin', function (req, res, next) {
    var reqUsername = req.body.username;
    var reqPassword = req.body.password;
    console.log(reqUsername);
    console.log(reqPassword);

    var getUser="select * from user where username='"+reqUsername+"' and password='" + reqPassword +"'";
    console.log("Query is: "+getUser);


    mysql.fetchData(function(err,results){
        if(err){
            throw err;
        }
        else
        {
            if(results.length > 0){
                console.log("valid Login");
                res.status(200).json({
                    data: results,
                    status:'200'
                });         }

            else {

                console.log("Invalid Login");
                res.status(201).json({
                    data: results,
                    status:'201'
                });
            }
        }
    },getUser);

});

module.exports = router;
