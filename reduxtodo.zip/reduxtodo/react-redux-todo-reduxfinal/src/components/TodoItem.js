import React, {Component} from 'react';
import {connect} from 'react-redux';

import {doneTodo} from "../actions/index";
import {removeTodo} from "../actions/index";

var abc={float:'right'};
class TodoItem extends Component {

    render() {

        const {item} = this.props;

        const todoClass = `alert alert-${item.status === 'done' ?  "success" : "danger"}`;



        return (
            <div className="row justify-content-md-center">
                <div className="col-md-12">
                    <div className={todoClass} role="alert">
                        { item.todo } {item.price}
                        { item.status === 'active' ? (
                            <button
                                className="btn btn-primary btn-sm" style={abc}
                                onClick={() => {
                                    this.props.doneTodo(item);
                                }}
                            ><span aria-hidden={true}>Add</span></button>) : ''}
                        { item.status === 'done' ? (
                            <button
                                className="btn btn-primary btn-sm" style={abc}
                                onClick={() => {
                                    this.props.removeTodo(item);
                                }}
                            ><span aria-hidden={true}>Remove</span></button>) : ''}
                    </div>
                </div>
            </div>
        );
    }
}

function mapDispatchToProps(dispatch) {
    return {
        doneTodo : (data) => dispatch(doneTodo(data)),
        removeTodo : (data) => dispatch(removeTodo(data))
    };
}

export default connect(null, mapDispatchToProps)(TodoItem);    // Learn 'Currying' in functional programming
